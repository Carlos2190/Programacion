/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete1;

/**
 *
 * @author KEVIN
 */
public class pr1 {
    private String nombre = "Universidad Tecnica Particular de Loja";
    private int númeroAlumnos = 3000;
    private int númeroDocentes = 4000;
    private int numeroSedes;
    private double gastosEstudiante = 100.50;
    private double presupuesto = 4000;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNúmeroAlumnos() {
        return númeroAlumnos;
    }

    public void setNúmeroAlumnos(int númeroAlumnos) {
        this.númeroAlumnos = númeroAlumnos;
    }

    public int getNúmeroDocentes() {
        return númeroDocentes;
    }

    public void setNúmeroDocentes(int númeroDocentes) {
        this.númeroDocentes = númeroDocentes;
    }

    public int getNumeroSedes() {
        return numeroSedes;
    }

    public void setNumeroSedes(int numeroSedes) {
        this.numeroSedes = numeroSedes;
    }

    public double getGastosEstudiante() {
        return gastosEstudiante;
    }

    public void setGastosEstudiante(double gastosEstudiante) {
        this.gastosEstudiante = gastosEstudiante;
    }

    public double getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(double presupuesto) {
        this.presupuesto = presupuesto;
    }
    
    
}
