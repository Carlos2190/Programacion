/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package problema03;
import paquete1.pr1;
public class Problema03 {

    public static void main(String[] args) {

       pr1 reporte = new pr1();
        

        reporte.setNombre("universidad Tecnica Particular de Loja");
        reporte.setNúmeroAlumnos(5000);
        reporte.setNúmeroDocentes(4000);
        reporte.setNumeroSedes(5);
        reporte.setGastosEstudiante(100.50);
        reporte.setPresupuesto(6000);
        
        
        System.out.println("----- REPORTE -----");
        System.out.println("Nombre Universidad: " + reporte.getNombre());
        System.out.println("Numero de Alumnos: " + reporte.getNúmeroAlumnos());
        System.out.println("Numero de Docentes: "+ reporte.getNúmeroDocentes());
        System.out.println("Numero de Sedes: "+ reporte.getNumeroSedes());
        System.out.println("Gatos de Estudiantes: "+ reporte.getGastosEstudiante());
        System.out.println("Presupuesto: " + reporte.getPresupuesto());
        
    }

}
