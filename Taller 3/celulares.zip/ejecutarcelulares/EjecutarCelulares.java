/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejecutarcelulares;

import celulares.celulares;

/**
 *
 * @author KEVIN
 */
public class EjecutarCelulares {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        celulares cell = new celulares();
        
        cell.setSisOperativo("Android");
        cell.setTamanoPantalla("6 Pulgadas");
        cell.setCostoInicial(350);
        cell.setIvaPorcentaje(15);
        cell.setDireccionMAC("00:1A:2B:3C:4D:5E");
        cell.setImei("123456789012345");
        
        
        System.out.println("------- REPORTE -------");
        System.out.println("Sistema Operativo: " + cell.getSisOperativo());
        System.out.println("Pantalla: " + cell.getTamanoPantalla());
        System.out.println("Costo inicial: " + cell.getCostoInicial());
        System.out.println("IVA: " + cell.getIvaPorcentaje());
        System.out.println("Direccion MAC: " + cell.getDireccionMAC());
        System.out.println("IMEI: " + cell.getImei());
        System.out.printf("Costo Final: %.2f\n", cell.getCostoFinal());
    }
    
}
